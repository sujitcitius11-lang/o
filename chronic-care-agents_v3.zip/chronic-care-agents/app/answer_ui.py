"""Structured member answers: short bullet points, tables for numbers and charts for readings.

Only the DISPLAY changes here. Every fact (counts, values, dates, rules) still comes from code in the orchestrator;
nothing is calculated by a model and no clinical meaning is added.
"""
from __future__ import annotations

import re

import pandas as pd
import streamlit as st

from app.theme import esc, html

MAX_BULLETS = 4
_SENT = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9\"(])")
_NO_ENTRY = re.compile(r"^(?P<type>.+?): no entry on (?P<day>\d{4}-\d{2}-\d{2})$")


# ----------------------------------------------------------------------------- text -> bullets
def to_bullets(text: str) -> list[str]:
    """Split an answer into short points. Lines that already are bullets stay; paragraphs are split into sentences."""
    out: list[str] = []
    for line in (text or "").splitlines():
        line = line.strip().lstrip("-*• ").strip()
        if not line:
            continue
        out += [s.strip() for s in _SENT.split(line) if s.strip()]
    return out


def _ul(items: list[str]) -> str:
    return "<ul style='margin:4px 0 4px 18px;padding:0;line-height:1.55'>" + "".join(f"<li>{esc(i)}</li>" for i in items) + "</ul>"


def _footer(sources: list[str], notice: str | None, disclaimer: str) -> str:
    chips = "".join(f'<span class="src-chip">{esc(s)}</span>' for s in sources)
    src = f'<div style="margin-top:6px"><span class="muted">Sources: </span>{chips}</div>' if chips else ""
    note = f'<div class="notice">{esc(notice)}</div>' if notice else ""
    return f'{src}{note}<div class="disclaimer">{esc(disclaimer)}</div>'


# ----------------------------------------------------------------------------- readings
def readings_frame(rows: list[dict]) -> pd.DataFrame:
    df = pd.DataFrame(rows)
    if df.empty:
        return df
    df["recorded_at"] = pd.to_datetime(df["recorded_at"], errors="coerce")
    return df.sort_values("recorded_at").reset_index(drop=True)


def _num(v) -> list[float] | None:
    try:
        return [float(x) for x in str(v).split("/")]
    except ValueError:
        return None


def _missing_by_type(missing: list[str]) -> dict[str, list[str]]:
    out: dict[str, list[str]] = {}
    for m in missing:
        mt = _NO_ENTRY.match(m)
        if mt:
            out.setdefault(mt["type"], []).append(mt["day"])
    return out


def _day_list(days: list[str]) -> str:
    ds = pd.to_datetime(pd.Series(days)).sort_values()
    return ", ".join(f"{d:%b} {d.day}" for d in ds)


def reading_bullets(df: pd.DataFrame, missing: list[str]) -> list[str]:
    """Plain facts from the table (count, date span, lowest/highest, days without an entry). No judgement words."""
    miss = _missing_by_type(missing)
    bullets = []
    for typ, g in df.groupby("type", sort=False):
        unit = g["unit"].iloc[0]
        vals = [_num(v) for v in g["value"]]
        span = f"{g['recorded_at'].min():%b} {g['recorded_at'].min().day} to {g['recorded_at'].max():%b} {g['recorded_at'].max().day}"
        if all(v and len(v) == 2 for v in vals):
            sy, di = [v[0] for v in vals], [v[1] for v in vals]
            rng = f"top number {min(sy):g} to {max(sy):g}, bottom number {min(di):g} to {max(di):g} {unit}"
        elif all(v for v in vals):
            flat = [v[0] for v in vals]
            rng = f"lowest {min(flat):g}, highest {max(flat):g} {unit}"
        else:
            rng = ""
        b = f"{typ}: {len(g)} reading(s), {span}" + (f"; {rng}" if rng else "")
        bullets.append(b)
        if typ in miss:
            bullets.append(f"{typ}: no entry on {len(miss[typ])} day(s) ({_day_list(miss[typ])})")
    for typ, days in miss.items():
        if typ not in set(df["type"]):
            bullets.append(f"{typ}: no entry on {len(days)} day(s) ({_day_list(days)})")
    return bullets


def readings_table(df: pd.DataFrame) -> None:
    show = df.assign(**{"Recorded at": df["recorded_at"].dt.strftime("%Y-%m-%d %H:%M")})
    show = show[["reading_id", "type", "value", "unit", "Recorded at"]].rename(columns={"reading_id": "Reading ID", "type": "Type", "value": "Value", "unit": "Unit"})
    st.dataframe(show, hide_index=True, width="stretch")


def readings_charts(df: pd.DataFrame, key: str = "") -> None:
    """One line chart per reading type. Blood pressure is drawn as two lines (top and bottom number)."""
    for typ, g in df.groupby("type", sort=False):
        vals = [_num(v) for v in g["value"]]
        if not all(vals):
            continue
        unit = g["unit"].iloc[0]
        if all(len(v) == 2 for v in vals):
            data = pd.DataFrame({"Top number": [v[0] for v in vals], "Bottom number": [v[1] for v in vals]}, index=g["recorded_at"])
        else:
            data = pd.DataFrame({typ: [v[0] for v in vals]}, index=g["recorded_at"])
        st.caption(f"{typ} ({unit}) over time")
        if len(g) == 1:
            st.bar_chart(data, height=150, color=["#0E7C86", "#2A8FC7"][: data.shape[1]])
        else:
            st.line_chart(data, height=200, color=["#0E7C86", "#2A8FC7"][: data.shape[1]])


# ----------------------------------------------------------------------------- care plan
def plan_bullets(actions: list[dict]) -> list[str]:
    due = [a for a in actions if a["status"] in ("Due", "Overdue")]
    up = [a for a in actions if a["status"] not in ("Due", "Overdue")]
    b = [f"{len(due)} task(s) need action ({sum(a['status'] == 'Overdue' for a in due)} overdue)", f"{len(up)} task(s) coming up"]
    if due:
        b.append("Next to do: " + "; ".join(a["task"] for a in due[:3]))
    return b


# ----------------------------------------------------------------------------- main renderer
def member_answer(res, uid: str) -> None:
    mr, pk, au = res.member_response, res.coordinator_packet, res.audit
    sources = [s.label() for s in mr.sources]
    df = readings_frame(pk.relevant_readings) if pk.relevant_readings else pd.DataFrame()
    category = au.category

    with st.container(border=True):
        st.caption("Care Assistant")
        if category == "READINGS" and not df.empty:
            bullets = reading_bullets(df, pk.missing_information)
            html(_ul(bullets))
            st.markdown("**Readings table**")
            readings_table(df)
            st.markdown("**Graph**")
            readings_charts(df, uid)
            if pk.corrections_applied:
                st.caption("Corrected entries used: " + ", ".join(f"{c['superseded']} → {c['replaced_by']}" for c in pk.corrections_applied))
            with st.expander("Full wording"):
                st.write(mr.text)
        elif category == "PLAN" and pk.due_actions:
            html(_ul(plan_bullets(pk.due_actions)))
            st.markdown("**Care plan tasks**")
            st.dataframe(pd.DataFrame(pk.due_actions).rename(columns=str.title), hide_index=True, width="stretch")
            if pk.reminder_draft:
                st.markdown("**Reminder draft**")
                st.info(pk.reminder_draft)
            with st.expander("Full wording"):
                st.write(mr.text)
        else:
            bullets = to_bullets(mr.text)
            html(_ul(bullets[:MAX_BULLETS]))
            if len(bullets) > MAX_BULLETS:
                with st.expander(f"More details ({len(bullets) - MAX_BULLETS} more point(s))"):
                    html(_ul(bullets[MAX_BULLETS:]))
        html(_footer(sources, mr.escalation_notice, mr.disclaimer))
