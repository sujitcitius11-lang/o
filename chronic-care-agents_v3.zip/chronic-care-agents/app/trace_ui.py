"""'What's happening behind the scenes' - friendly lines for each agent call (live and in chat history).

Works on the event/AgentCall dicts emitted by AuditTrail: {agent, step, tools, status, duration_ms, detail}.
"""

from __future__ import annotations

import html
import re
from datetime import date

ICONS = {
    "CareOrchestrator": "🧭",
    "ReadingSummaryAgent": "📈",
    "CarePlanAgent": "🗓️",
    "EducationRAGAgent": "📚",
    "RouterAgent": "🧭",
    "KeywordClassifier": "🔤",
    "EngagementAgent": "🔔",
    "EscalationAgent": "🛡️",
}
_RANGE = re.compile(r"range=(\d{4}-\d{2}-\d{2})\.\.(\d{4}-\d{2}-\d{2}); count=(\d+)")


def _short(iso: str) -> str:
    d = date.fromisoformat(iso)
    return f"{d:%b} {d.day}"


def where(call: dict) -> list[str]:
    """Badges for where the work ran."""
    detail = call.get("detail") or ""
    tools = call.get("tools") or []
    badges = []
    if "foundry_agent" in detail or "agentic_llm" in detail:
        badges.append('<span class="tr-badge foundry">☁️ Foundry agent</span>')
    elif "method=extractive" in detail:
        badges.append('<span class="tr-badge code">📄 quoted fallback</span>')
    elif call.get("status") == "ok":
        badges.append('<span class="tr-badge code">⚙️ Python code / templates</span>')
    if "azure_ai_search" in tools:
        badges.append('<span class="tr-badge search">🔎 Azure AI Search</span>')
    return badges


def result_text(call: dict) -> str:
    detail = call.get("detail") or ""
    status = call.get("status")
    if status == "failed":
        return "service unavailable - nothing estimated"
    if status == "skipped":
        return detail
    if m := _RANGE.search(detail):
        start, end, count = m.groups()
        return f"{_short(start)} to {_short(end)} · {count} reading(s)"
    if "scope=" in detail:
        return "scope: " + detail.split("scope=")[1]
    if "method=agentic_llm" in detail:
        return "cited answer written"
    if "method=extractive" in detail:
        return "quoted from approved text"
    if "found=False" in detail:
        return "no matching approved article"
    return ""


def trace_line(call: dict, running: bool = False) -> str:
    agent = call.get("agent", "")
    step = call.get("step") or ""
    icon = ICONS.get(agent, "•")
    if running:
        secs = (call.get("duration_ms") or 0) / 1000
        meta = f'<span class="tr-meta"><span class="tr-spin"></span>working… {secs:.1f}s</span>'
        badges = ""
    else:
        mark = {"ok": "✓", "failed": "⚠️", "skipped": "⏭"}.get(call.get("status"), "✓")
        secs = (call.get("duration_ms") or 0) / 1000
        extra = result_text(call)
        meta = f'<span class="tr-meta">{mark} {secs:.1f}s' + (f" · {html.escape(extra)}" if extra else "") + "</span>"
        badges = "".join(where(call))
    return (f'<div class="tr-line{" running" if running else ""}"><span class="tr-ico">{icon}</span>'
            f'<div class="tr-main"><div><b>{html.escape(agent)}</b> <span class="tr-step">{html.escape(step)}</span></div>'
            f'<div class="tr-sub">{badges}{meta}</div></div></div>')


def live_html(calls: list[dict]) -> str:
    """The agent timeline while the request is still running: finished steps with times, the current step spinning."""
    if not calls:
        return '<div class="tr-sub"><span class="tr-meta"><span class="tr-spin"></span>starting…</span></div>'
    return "".join(trace_line(c, running=c.get("status") == "running") for c in calls)


def trace_label(elapsed: float, calls: list[dict]) -> str:
    agents = len({c.get("agent") for c in calls if c.get("status") == "ok"})
    return f"✨ Worked for {elapsed:.1f}s · {agents} agent{'s' if agents != 1 else ''} · click to see each step"


TRACE_CSS = """
.tr-line {display:flex; gap:.6rem; align-items:flex-start; padding:.35rem 0; border-bottom:1px dashed #edf1ef; animation:cc-in .3s ease both;}
.tr-line:last-child {border-bottom:none;}
.tr-ico {width:1.6rem; height:1.6rem; flex:none; display:grid; place-items:center; border-radius:8px; background:#f0f7f5; font-size:.9rem;}
.tr-main {min-width:0; font-size:.86rem; line-height:1.35;}
.tr-step {color:#6b7c77;}
.tr-sub {display:flex; flex-wrap:wrap; gap:.35rem; align-items:center; margin-top:.15rem;}
.tr-badge {font-size:.68rem; padding:.05rem .45rem; border-radius:999px; white-space:nowrap;}
.tr-badge.foundry {background:#e8efff; color:#2563eb;}
.tr-badge.code {background:#eef0ef; color:#4b5b56;}
.tr-badge.search {background:#e6f4f1; color:#0f766e;}
.tr-meta {font-size:.74rem; color:#8a9a95; display:inline-flex; align-items:center; gap:.3rem;}
.tr-line.running .tr-ico {animation:cc-pulse 1.2s ease-in-out infinite;}
.tr-spin {width:10px; height:10px; border-radius:50%; border:2px solid #cfe5df; border-top-color:#14b8a6; animation:tr-spin .8s linear infinite;}
@keyframes tr-spin {to {transform:rotate(360deg);}}
@keyframes cc-pulse {0%,100% {transform:scale(1);} 50% {transform:scale(1.12);}}
[data-testid="stExpander"] details summary p, [data-testid="stStatusWidget"] p {font-size:.85rem; color:#4b5b56;}
"""
