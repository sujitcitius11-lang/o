# HMS — Claude Code setup (FastAPI + Streamlit)

Claude Code version of the Copilot HMS customizations: same agents, skills, rules and specs, plus
**pipeline commands** (one slash command runs every agent in order), a **deterministic environment/gate script**
and **hooks** that remove work from the model.

## Quick start (VS Code, Claude Code extension or terminal)
1. Open this folder in VS Code → start Claude Code.
2. Review `specs/DECISIONS.md` (defaults for every open question; edit anything you disagree with).
3. Run **`/build-patient-api`** — it creates the venv, installs deps, scaffolds the foundation, builds `auth` (a prerequisite), then `patients`, and reports.
   Or run **`/build-app`** for every module + Streamlit pages (resumable; `/build-app api` skips UI).
4. Run: `uvicorn app.main:app --reload` and `streamlit run ui/Home.py`. First admin: `python -m app.modules.auth.cli create-admin --email you@example.com` (created by the auth build).

## Commands (`.claude/commands/`)
| Command | What it does |
|---|---|
| `/setup-env` | venv, deps, `.env` (random JWT secret), foundation scaffold, smoke tests |
| `/build-patient-api [ui]` | the pipeline below, fixed to `patients` — **copy this file to make new pipelines** |
| `/build-module <m> [ui]` | same pipeline for any module |
| `/build-app [api]` | all unblocked modules in dependency order |
| `/review-diff [module]` · `/slice-brd <path>` · `/hms-status` | read-only review · BRD → specs · status table |

## The pipeline (`build-patient-api.md`)
`preflight` (script) → `codegen` (agent `code-generator`) → `migrate` (script) → `backend` (`backend-developer`) → `tests` (`test-generator`) → `validate` (script, one fix round) → `review` (`code-reviewer`, one fix round) → `ui` (optional, `frontend-developer`) → `finish`.
Agents never call each other; the command is the orchestrator. Each stage is checkpointed in `.work/<module>/state.json`, so a re-run resumes and never repeats finished stages.

## Where the token savings come from
- Boilerplate (db, JWT, RBAC, audit, app factory, API client, test fixtures, Alembic) is a **tested template** copied by script — no model tokens.
- Gates (`preflight`, `migrate`, `validate`) are scripts that print 1–40 lines; ruff format/fix runs in a **hook** after every edit and is silent on success.
- Subagents run in their own context, reply in ≤5 lines, and pass details through `.work/<module>/handoff.md`.
- `CLAUDE.md` is ~770 words of rule IDs (agents reference IDs, never restate); skills are read on demand.
- `.ignore` + permission denies keep agents out of `.venv`, caches, DB files and logs; a guard hook blocks `.env` access.
- Tuning: each agent has a `model:` line (all `sonnet`; try `haiku` for `frontend-developer`). Keep the main session on Sonnet — the orchestrator only sequences. Use `/context` and `/cost` to measure; `/clear` between modules is safe.

## Behavior to know
- `specs/DECISIONS.md` statuses: `proposed` (built, listed in the final report), `approved`, `blocked` (skipped). Services, notifications, PDF export, gateway payments, lab file upload, refunds are marked blocked/out of scope.
- "Only `spec-slicer` reads the BRD" (R01) is a rule, not a hard technical block.
- Prompt guardrail (ported): blocks prompts containing deny-list words (`.claude/hooks/guard_config.json`, set `"enabled": false` to disable). Prompt metadata (hash/length only) is logged to `.claude/logs/prompts.jsonl`.
- Access tokens are stateless (30 min); deactivating a user takes effect at expiry (see `global` decisions).
- Edit rules only in `CLAUDE.md`; `python .claude/scripts/check_rule_ids.py` (also pre-commit) fails on undefined IDs.

## Layout
```
CLAUDE.md                      rules + layout + token rules (always loaded)
specs/                         module contracts + DECISIONS.md
.claude/agents/                spec-slicer, code-generator, backend-developer, frontend-developer, test-generator, code-reviewer
.claude/commands/              pipelines
.claude/skills/                8 on-demand skills (ported)
.claude/scripts/hms.py         bootstrap · preflight · migrate · validate · status · mark
.claude/hooks/                 guard, format_on_edit, prompt_guard
.claude/templates/foundation/  scaffolded app core, UI client, tests, Alembic env
```
