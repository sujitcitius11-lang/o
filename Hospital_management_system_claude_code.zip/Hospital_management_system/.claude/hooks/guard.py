"""PreToolUse guard: protect secrets, block destructive commands, keep agents out of noisy dirs (T01)."""

import re
import sys
from pathlib import PurePath

from _common import project_root, read_event

ENV_FILE = re.compile(r"(?<![\w.-])\.env(?:\.(?!example\b)[\w-]+)?(?![\w.-])")
DANGEROUS = [
    (re.compile(r"\brm\s+-[a-z]*r[a-z]*f|\brm\s+-[a-z]*f[a-z]*r|\brm\s+--recursive"), "recursive delete"),
    (re.compile(r"\bgit\s+push\b"), "git push"),
    (re.compile(r"\bgit\s+(reset\s+--hard|clean\s+-[a-z]*f)"), "destructive git command"),
    (re.compile(r"\bdrop\s+(database|schema)\b", re.I), "DROP DATABASE/SCHEMA"),
    (re.compile(r"(curl|wget)[^|]*\|\s*(sh|bash|python)"), "pipe-to-shell"),
]
NOISY_DIRS = (".venv", "venv", "node_modules", "__pycache__", ".git")


def block(msg: str) -> int:
    print(f"Blocked by HMS guard: {msg}", file=sys.stderr)
    return 2


def main() -> int:
    event = read_event()
    tool = event.get("tool_name", "")
    inp = event.get("tool_input") or {}
    if tool == "Bash":
        cmd = inp.get("command", "")
        if ENV_FILE.search(cmd):
            return block("commands may not touch .env files (R08)")
        for pattern, label in DANGEROUS:
            if pattern.search(cmd):
                return block(f"{label} is not allowed in pipelines")
        return 0
    path = inp.get("file_path") or inp.get("path") or ""
    if not path:
        return 0
    p = PurePath(path.replace("\\", "/"))
    try:  # judge only the part below the project root
        p = p.relative_to(project_root().as_posix())
    except ValueError:
        pass
    parts = p.parts
    name = parts[-1] if parts else ""
    if name.startswith(".env") and name != ".env.example":
        return block("secret file (R08)")
    if any(p in NOISY_DIRS for p in parts):
        return block(f"{path} is excluded to save tokens (T01)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
