"""PostToolUse(Edit|Write|MultiEdit): ruff format + autofix on the edited .py file.

Silent on success (zero tokens). Prints only unfixable lint errors (exit 2 feeds them to Claude).
"""

import subprocess
import sys
from pathlib import Path

from _common import project_root, read_event, venv_python


def main() -> int:
    event = read_event()
    path = (event.get("tool_input") or {}).get("file_path", "")
    if not path.endswith(".py"):
        return 0
    root = project_root()
    target = Path(path)
    if not target.is_absolute():
        target = root / target
    rel = target.resolve().relative_to(root) if target.resolve().is_relative_to(root) else None
    if rel is None or not target.exists() or rel.parts[0] in (".claude", ".venv", "migrations"):
        return 0
    py = venv_python(root)
    if py is None:
        return 0
    try:
        subprocess.run([str(py), "-m", "ruff", "format", "-q", str(target)], cwd=root, timeout=30)
        subprocess.run(
            [str(py), "-m", "ruff", "check", "--fix", "-q", str(target)], cwd=root, timeout=30
        )
        out = subprocess.run(
            [str(py), "-m", "ruff", "check", "--output-format", "concise", str(target)],
            cwd=root,
            capture_output=True,
            text=True,
            timeout=30,
        )
    except (subprocess.TimeoutExpired, OSError):
        return 0
    if out.returncode != 0 and "No module named" not in (out.stderr or ""):
        lines = [ln for ln in out.stdout.strip().splitlines() if ln.strip()][:10]
        print("Ruff: unfixed issues\n" + "\n".join(lines), file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
