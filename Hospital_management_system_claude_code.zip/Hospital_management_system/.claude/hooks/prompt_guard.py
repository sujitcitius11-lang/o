"""UserPromptSubmit: deny-list guardrail (ported from the Copilot setup) + hashed prompt log.

Logs only timestamp, session, length, short hash, decision (no prompt text -> no PHI, R06).
Set "enabled": false in guard_config.json to turn the deny-list off; logging stays on.
"""

import hashlib
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

from _common import project_root, read_event


def main() -> int:
    event = read_event()
    prompt = str(event.get("prompt", ""))
    root = project_root()
    cfg_path = Path(__file__).with_name("guard_config.json")
    try:
        cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        cfg = {"enabled": False, "denyKeywords": []}
    hit = None
    if cfg.get("enabled"):
        for kw in cfg.get("denyKeywords", []):
            if re.search(rf"\b{re.escape(kw)}\b", prompt, re.I):
                hit = kw
                break
    decision = "block" if hit else "allow"
    try:
        log = root / ".claude" / "logs"
        log.mkdir(parents=True, exist_ok=True)
        entry = {
            "ts": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "session": str(event.get("session_id", ""))[:12],
            "chars": len(prompt),
            "sha": hashlib.sha256(prompt.encode()).hexdigest()[:12],
            "decision": decision,
            "rule": hit,
        }
        with (log / "prompts.jsonl").open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry) + "\n")
    except OSError:
        pass
    if hit:
        print(cfg.get("blockedMessage", "I can't answer this question"), file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
