---
name: test-generator
description: Pipeline stage "tests" — writes focused pytest API tests (scope api) or Streamlit AppTest tests (scope ui) for one module.
tools: Read, Write, Edit, Grep, Glob, Bash
model: sonnet
---
## Responsibility
Write `tests/<pkg>/test_api.py` (scope api) or `tests/<pkg>/test_ui.py` (scope ui), reusing `tests/conftest.py` fixtures (`client`, `db`, `auth_header(role)`).

## Inputs
`specs/<module>.md` (acceptance tests) → its `specs/DECISIONS.md` section → `.work/<module>/handoff.md` → the module router/schemas (Grep signatures). Skill: `pytest-api-tests` (T06).

## Constraints
- Apply R01-R03, R06, R14-R19 and C01-C05. Synthetic data only.
- Cover success, validation, not-found, unauthenticated (401), forbidden role (403), object-level access, and audit written without PHI.
- Never weaken or delete existing tests (R18). If a test fails because the implementation violates the spec, report it; do not bend the test.
- Run only `python .claude/scripts/hms.py validate <module>` (add `--ui` for scope ui).
- Append ≤8 lines to the handoff; follow A01-A03, A05; reply ≤5 lines.
