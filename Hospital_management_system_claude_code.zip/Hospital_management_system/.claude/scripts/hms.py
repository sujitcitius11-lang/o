#!/usr/bin/env python3
"""HMS project CLI: deterministic, token-cheap gates for the Claude Code pipelines.

Stdlib only. Run with any system Python; it drives the project's .venv itself.

  bootstrap [--no-install]   venv + deps + .env + foundation scaffold + smoke test (idempotent)
  scaffold                   copy foundation templates (never overwrites)
  preflight <module>         env/foundation/spec-gate/prereq/resume summary
  order                      modules still to build, dependency order, blocked excluded
  status                     table of all modules
  mark <module> <stage>      checkpoint a pipeline stage
  migrate "<message>"        alembic autogenerate + upgrade (skips empty migrations)
  validate <module|foundation|all> [--ui]   ruff + pytest, trimmed output
"""

from __future__ import annotations

import hashlib
import json
import re
import secrets
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TEMPLATES = ROOT / ".claude" / "templates" / "foundation"
WORK = ROOT / ".work"
SPECS = ROOT / "specs"

# module -> prerequisites. Dict order is a valid build order.
MODULES: dict[str, list[str]] = {
    "auth": [],
    "patients": ["auth"],
    "doctors-departments": ["auth"],
    "appointments": ["auth", "patients", "doctors-departments"],
    "prescriptions": ["appointments"],
    "lab": ["patients"],
    "pharmacy": ["prescriptions"],
    "billing": ["patients", "appointments"],
    "reports": ["billing", "appointments"],
}


def pkg(module: str) -> str:
    return module.replace("-", "_")


def venv_python() -> Path:
    win = ROOT / ".venv" / "Scripts" / "python.exe"
    return win if win.exists() else ROOT / ".venv" / "bin" / "python"


def run(cmd: list[str], timeout: int = 900) -> tuple[int, str]:
    try:
        p = subprocess.run(
            cmd, cwd=ROOT, capture_output=True, text=True, timeout=timeout, encoding="utf-8", errors="replace"
        )
    except subprocess.TimeoutExpired:
        return 124, f"timeout after {timeout}s: {' '.join(cmd[:4])}"
    except FileNotFoundError as e:
        return 127, str(e)
    return p.returncode, (p.stdout or "") + (p.stderr or "")


def tail(text: str, n: int = 40) -> str:
    lines = [ln for ln in text.strip().splitlines() if ln.strip()]
    return "\n".join(lines[-n:])


def vpy(*args: str, timeout: int = 900) -> tuple[int, str]:
    return run([str(venv_python()), *args], timeout)


# ------------------------------------------------------------------ state
def state_path(module: str) -> Path:
    return WORK / pkg(module) / "state.json"


def load_state(module: str) -> dict:
    p = state_path(module)
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            pass
    return {"stages": {}}


def is_done(module: str) -> bool:
    return "done" in load_state(module)["stages"]


def cmd_mark(module: str, stage: str) -> int:
    st = load_state(module)
    st["stages"][stage] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    p = state_path(module)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(st, indent=1), encoding="utf-8")
    (p.parent / "handoff.md").touch(exist_ok=True)
    print(f"MARK {module}:{stage}")
    return 0


# ------------------------------------------------------------------ spec gate
def gate_status(module: str) -> str:
    """Return approved|proposed|blocked|missing from specs/DECISIONS.md."""
    f = SPECS / "DECISIONS.md"
    if not f.exists():
        return "missing"
    text = f.read_text(encoding="utf-8")
    for m in re.finditer(r"^## (\S+)\s*\n(.*?)(?=^## |\Z)", text, re.MULTILINE | re.DOTALL):
        if m.group(1) == module:
            s = re.search(r"^Status:\s*(\w+)", m.group(2), re.MULTILINE)
            return s.group(1).lower() if s else "missing"
    return "missing"


def missing_prereqs(module: str, seen: list[str] | None = None) -> list[str]:
    out: list[str] = seen if seen is not None else []
    for dep in MODULES.get(module, []):
        missing_prereqs(dep, out)
        if not is_done(dep) and dep not in out:
            out.append(dep)
    return out


# ------------------------------------------------------------------ env
def env_ok() -> bool:
    if not venv_python().exists():
        return False
    rc, _ = vpy("-c", "import fastapi, sqlalchemy, alembic, jwt, bcrypt, httpx, pytest", timeout=60)
    return rc == 0


def foundation_ok() -> bool:
    need = ["app/main.py", "app/core/db.py", "app/core/deps.py", "app/core/security.py", "tests/conftest.py"]
    return all((ROOT / n).exists() for n in need)


def cmd_preflight(module: str) -> int:
    if module not in MODULES:
        print(f"RESULT: BLOCKED\nREASON: unknown module '{module}'. Valid: {', '.join(MODULES)}")
        return 0
    env, fnd = env_ok(), foundation_ok()
    spec = (SPECS / f"{module}.md").exists()
    gate = gate_status(module)
    pre = missing_prereqs(module)
    done = [s for s in load_state(module)["stages"]]
    print(f"ENV: {'OK' if env else 'MISSING'}")
    print(f"FOUNDATION: {'OK' if fnd else 'MISSING'}")
    print(f"SPEC: specs/{module}.md {'OK' if spec else 'MISSING'}")
    print(f"GATE: {gate}" + (f"  (assumptions: specs/DECISIONS.md#{module})" if gate == "proposed" else ""))
    print(f"PREREQS_MISSING: {', '.join(pre) if pre else 'none'}")
    print(f"DONE_STAGES: {', '.join(done) if done else 'none'}")
    if not spec or gate in ("blocked", "missing"):
        why = "spec file missing" if not spec else f"decision status is '{gate}' — edit specs/DECISIONS.md"
        print(f"RESULT: BLOCKED\nREASON: {why}")
    elif not (env and fnd):
        print("RESULT: NEEDS_ENV")
    elif pre:
        blocked = [p for p in pre if gate_status(p) in ("blocked", "missing")]
        if blocked:
            print(f"RESULT: BLOCKED\nREASON: prerequisite(s) blocked: {', '.join(blocked)}")
        else:
            print("RESULT: NEEDS_PREREQ")
    else:
        print("RESULT: READY")
    return 0


def cmd_order() -> int:
    todo, skipped = [], []
    for m in MODULES:
        if is_done(m):
            continue
        (skipped if gate_status(m) in ("blocked", "missing") else todo).append(m)
    print("BUILD_ORDER: " + (", ".join(todo) if todo else "none (all done)"))
    if skipped:
        print("BLOCKED: " + ", ".join(skipped))
    return 0


def cmd_status() -> int:
    print(f"{'module':<22}{'gate':<10}{'state':<10}stages")
    for m in MODULES:
        st = load_state(m)["stages"]
        state = "done" if "done" in st else ("partial" if st else "-")
        print(f"{m:<22}{gate_status(m):<10}{state:<10}{','.join(st) if st else '-'}")
    print(f"env={'OK' if env_ok() else 'MISSING'} foundation={'OK' if foundation_ok() else 'MISSING'}")
    return 0


# ------------------------------------------------------------------ scaffold / bootstrap
def cmd_scaffold() -> int:
    created = 0
    for src in sorted(TEMPLATES.rglob("*")):
        if src.is_dir():
            continue
        dst = ROOT / src.relative_to(TEMPLATES)
        if dst.exists():
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
        created += 1
    print(f"SCAFFOLD: {created} file(s) created, existing files untouched")
    return 0


def write_env_file() -> str:
    env = ROOT / ".env"
    if env.exists():
        return ".env kept"
    example = ROOT / ".env.example"
    body = example.read_text(encoding="utf-8") if example.exists() else ""
    body = re.sub(r"^HMS_JWT_SECRET=.*$", f"HMS_JWT_SECRET={secrets.token_urlsafe(48)}", body, flags=re.MULTILINE)
    env.write_text(body, encoding="utf-8")
    return ".env created (random JWT secret)"


def cmd_bootstrap(args: list[str]) -> int:
    install = "--no-install" not in args
    lines: list[str] = []
    cmd_scaffold_msg = io_capture(cmd_scaffold)
    lines.append(cmd_scaffold_msg)
    if not venv_python().exists():
        rc, out = run([sys.executable, "-m", "venv", str(ROOT / ".venv")], 300)
        if rc != 0:
            print("FAIL venv\n" + tail(out, 15))
            return 1
        lines.append("venv created")
    if install:
        req = ROOT / "requirements.txt"
        digest = hashlib.sha256(req.read_bytes()).hexdigest() if req.exists() else ""
        marker = ROOT / ".venv" / ".hms_deps"
        if marker.exists() and marker.read_text() == digest and env_ok():
            lines.append("deps up to date")
        else:
            rc, _ = vpy("-m", "pip", "--version", timeout=60)
            if rc != 0:
                vpy("-m", "ensurepip", "--upgrade", timeout=300)
            rc, out = vpy("-m", "pip", "install", "-q", "-r", "requirements.txt", timeout=1500)
            if rc != 0:
                print("FAIL pip install\n" + tail(out, 20))
                return 1
            marker.write_text(digest)
            lines.append("deps installed")
    lines.append(write_env_file())
    if not (ROOT / ".git").exists() and shutil.which("git"):
        run(["git", "init", "-q"])
        lines.append("git repo initialised (needed by ripgrep ignore rules and pre-commit)")
    print("\n".join(lines))
    rc = cmd_validate("foundation", [])
    if rc == 0:
        print("BOOTSTRAP OK — next: /build-patient-api  (or /build-app)")
    return rc


def io_capture(fn) -> str:
    import contextlib
    import io

    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        fn()
    return buf.getvalue().strip()


# ------------------------------------------------------------------ migrate
def cmd_migrate(message: str) -> int:
    if not (ROOT / "alembic.ini").exists():
        print("FAIL migrate: alembic.ini missing — run bootstrap")
        return 1
    rc, out = vpy("-m", "alembic", "revision", "--autogenerate", "-m", message)
    if rc != 0:
        print("FAIL migrate (autogenerate)\n" + tail(out, 25))
        return 1
    m = re.search(r"Generating (\S+versions\S+\.py)", out)
    rc, out2 = vpy("-m", "alembic", "upgrade", "head")
    if rc != 0:
        print("FAIL migrate (upgrade)\n" + tail(out2, 25))
        return 1
    print(f"MIGRATE OK {Path(m.group(1)).name if m else '(no schema changes)'}")
    return 0


# ------------------------------------------------------------------ validate
def validate_paths(module: str, ui: bool) -> tuple[list[str], list[str]]:
    if module == "foundation":
        return ["app/core", "app/main.py", "ui", "tests/conftest.py", "tests/test_foundation.py"], [
            "tests/test_foundation.py"
        ]
    if module == "all":
        return ["app", "ui", "tests"], ["tests"]
    p = pkg(module)
    lint = [f"app/modules/{p}", f"tests/{p}"]
    if (ROOT / f"ui/pages/{p}.py").exists():
        lint.append(f"ui/pages/{p}.py")
    return lint, [f"tests/{p}"]


def cmd_validate(module: str, args: list[str]) -> int:
    ui = "--ui" in args
    if module not in MODULES and module not in ("foundation", "all"):
        print(f"FAIL validate: unknown module '{module}'")
        return 1
    if not env_ok():
        print("FAIL validate: environment missing — run bootstrap")
        return 1
    lint, tests = validate_paths(module, ui)
    lint = [p for p in lint if (ROOT / p).exists()]
    tests = [p for p in tests if (ROOT / p).exists()]
    if not tests:
        print(f"FAIL validate {module}: no tests found (expected tests/<module>/)")
        return 1
    notes = []
    if module == "all":
        rc, out = run([sys.executable, str(ROOT / ".claude/scripts/check_rule_ids.py")], 60)
        if rc != 0:
            print("FAIL rule-ids\n" + tail(out, 20))
            return 1
        notes.append("rule-ids ok")
    vpy("-m", "ruff", "format", *lint, timeout=120)
    vpy("-m", "ruff", "check", "--fix", "--quiet", *lint, timeout=120)
    rc, out = vpy("-m", "ruff", "check", "--output-format", "concise", *lint, timeout=120)
    if rc != 0:
        print(f"FAIL ruff ({module})\n" + tail(out, 25))
        return 1
    notes.append("ruff ok")
    rc, out = vpy("-m", "pytest", "-x", "--tb=short", "-p", "no:cacheprovider", *tests, timeout=1200)
    found = re.findall(r"^=*\s*(\d+ (?:passed|failed|error).*?)(?: in [\d.]+s.*)?\s*=*$", out, re.MULTILINE)
    summary = found[-1] if found else tail(out, 1)
    if rc != 0:
        print(f"FAIL pytest ({module})\n" + tail(out, 40))
        return 1
    notes.append(f"pytest: {summary}")
    print(f"PASS {module}: " + " · ".join(notes))
    return 0


# ------------------------------------------------------------------ main
def main(argv: list[str]) -> int:
    if len(argv) < 2 or argv[1] in ("-h", "--help"):
        print(__doc__)
        return 0
    cmd, rest = argv[1], argv[2:]
    if cmd == "bootstrap":
        return cmd_bootstrap(rest)
    if cmd == "scaffold":
        return cmd_scaffold()
    if cmd == "preflight" and rest:
        return cmd_preflight(rest[0])
    if cmd == "order":
        return cmd_order()
    if cmd == "status":
        return cmd_status()
    if cmd == "mark" and len(rest) >= 2:
        return cmd_mark(rest[0], rest[1])
    if cmd == "migrate" and rest:
        return cmd_migrate(rest[0])
    if cmd == "validate" and rest:
        return cmd_validate(rest[0], rest[1:])
    print(__doc__)
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
