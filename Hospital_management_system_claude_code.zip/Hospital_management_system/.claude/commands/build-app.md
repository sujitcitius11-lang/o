---
description: Build the whole HMS — every unblocked module in dependency order (backend + Streamlit UI). Resumable.
argument-hint: [api]  — "api" = backend only, skip Streamlit pages
---
# Pipeline: build-app  (extra = "$ARGUMENTS")

ORCHESTRATOR (T07). Do not read or write application code. Do not recap between modules; print one line `✔ <module>` each.

1. `python .claude/scripts/hms.py bootstrap` (idempotent; stop on FAIL).
2. `python .claude/scripts/hms.py order` → modules still to build, already in dependency order, `blocked` ones excluded (list them in the final report).
3. Read `.claude/commands/build-module.md` once. For each module from step 2, execute that pipeline with `$1 = <module>` and `$2 = ui` unless the extra is `api`. Stop at the first FAIL.
4. `python .claude/scripts/hms.py validate all`
5. Final report (≤12 lines): modules built, modules skipped/blocked, test result, `proposed` decisions used (`specs/DECISIONS.md`), run commands: `uvicorn app.main:app --reload` and `streamlit run ui/Home.py`.

Context tip: progress is checkpointed per stage in `.work/`. If the session gets long, `/clear` and run `/build-app` again; it resumes where it stopped.
