---
description: One-time environment setup — venv, dependencies, .env, foundation scaffold, smoke tests
---
Run `python .claude/scripts/hms.py bootstrap`. Show only its last 15 lines. If it reports FAIL, stop. Do nothing else.
