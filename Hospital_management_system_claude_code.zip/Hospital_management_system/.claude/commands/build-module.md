---
description: Build one HMS module end-to-end with the standard pipeline (generic version of build-patient-api)
argument-hint: <module> [ui]   e.g. "appointments" or "appointments ui"
---
# Pipeline: build-module  (module = $1 · extra = "$2")

You are the ORCHESTRATOR (T07): sequence the stages strictly in order, one subagent at a time. Never read or write application code yourself. Valid modules: auth, patients, doctors-departments, appointments, prescriptions, lab, pharmacy, billing, reports.

**Delegation prompt** (verbatim, fill `<stage>`):
`Module: $1. Stage: <stage>. Follow your agent file. Inputs: specs/$1.md, the "$1" section of specs/DECISIONS.md, .work/$1/handoff.md. Reply in ≤5 lines.`

**After each stage** run `python .claude/scripts/hms.py mark $1 <stage>`.
**On any FAIL or BLOCKED**: stop, show the gate output (≤40 lines) and the stage to resume from. Re-running resumes automatically (T05).

## Stages
1. **preflight** — `python .claude/scripts/hms.py preflight $1`
   - `NEEDS_ENV` → run `python .claude/scripts/hms.py bootstrap`, repeat.
   - `NEEDS_PREREQ` → run this same pipeline (no UI) for each module in `PREREQS_MISSING`, in order, then repeat.
   - `BLOCKED` → stop and report. Otherwise continue at the first stage not in `DONE_STAGES`.
2. **codegen** — agent `code-generator`.
3. **migrate** — `python .claude/scripts/hms.py migrate "$1 models"`
4. **backend** — agent `backend-developer`.
5. **tests** — agent `test-generator` (Scope: api).
6. **validate** — `python .claude/scripts/hms.py validate $1`; on FAIL delegate once to `backend-developer` (or `test-generator` for test-only failures) with the gate output, validate again, still FAIL → stop.
7. **review** — agent `code-reviewer` (Scope: files in handoff). `VERDICT: FIX` → one fix round by `backend-developer`, validate again; leftovers go in the report.
8. **ui** — only if the extra is `ui`: `frontend-developer`, then `test-generator` (Scope: ui), then `python .claude/scripts/hms.py validate $1 --ui`.
9. **finish** — `python .claude/scripts/hms.py mark $1 done`; print ≤8 lines: files, tests, verdict, `proposed` assumptions used (`specs/DECISIONS.md#$1`).
