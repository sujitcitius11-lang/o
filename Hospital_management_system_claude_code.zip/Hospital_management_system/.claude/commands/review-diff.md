---
description: Read-only review of the current change or one module
argument-hint: [module]  — omit to review the git diff
---
Delegate to the `code-reviewer` agent. Prompt: `Scope: $ARGUMENTS (empty = current git diff). Follow your agent file.` Show its reply unchanged. Do not edit files.
