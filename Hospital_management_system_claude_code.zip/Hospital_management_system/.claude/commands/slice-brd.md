---
description: Slice a BRD into per-module contracts (the only step allowed to read the BRD)
argument-hint: <brd-path> [modules...]
---
Delegate to the `spec-slicer` agent. Prompt: `BRD and modules: $ARGUMENTS. Follow your agent file.` Show its reply unchanged. Afterwards remind the user to fill the new `blocked` sections in `specs/DECISIONS.md`.
