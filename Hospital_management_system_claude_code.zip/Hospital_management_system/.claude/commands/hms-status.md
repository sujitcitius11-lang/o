---
description: Show build status of every HMS module (gate, stages done, prerequisites)
---
Run `python .claude/scripts/hms.py status` and show its output unchanged. Do nothing else.
