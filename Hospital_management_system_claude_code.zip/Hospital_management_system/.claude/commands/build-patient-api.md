---
description: Build the Patient API end-to-end (env → prerequisites → codegen → backend → tests → review → validate) with one command
argument-hint: [ui]  — optional: also build the Streamlit patients page
---
# Pipeline: build-patient-api  (module = patients · extra = "$ARGUMENTS")

You are the ORCHESTRATOR (T07): sequence the stages below strictly in order, one subagent at a time. Never read or write application code yourself.

**Delegation prompt** (use verbatim, fill `<stage>`):
`Module: patients. Stage: <stage>. Follow your agent file. Inputs: specs/patients.md, the "patients" section of specs/DECISIONS.md, .work/patients/handoff.md. Reply in ≤5 lines.`

**After each stage** run `python .claude/scripts/hms.py mark patients <stage>`.
**On any FAIL or BLOCKED**: stop, show the gate output (≤40 lines) and the stage to resume from. Re-running this command resumes automatically (T05).

## Stages
1. **preflight** — script, no agent: `python .claude/scripts/hms.py preflight patients`
   - `RESULT: NEEDS_ENV` → run `python .claude/scripts/hms.py bootstrap`, then repeat this step.
   - `RESULT: NEEDS_PREREQ` → for each module in `PREREQS_MISSING` (in order; for patients this is `auth`) read `.claude/commands/build-module.md` once and execute it with that module and no UI. Then repeat this step.
   - `RESULT: BLOCKED` → stop and report why. Otherwise continue with the first stage not in `DONE_STAGES`.
2. **codegen** — agent `code-generator` → models + schemas.
3. **migrate** — script gate: `python .claude/scripts/hms.py migrate "patients models"`
4. **backend** — agent `backend-developer` → service + router, RBAC, audit.
5. **tests** — agent `test-generator` (add "Scope: api" to the prompt).
6. **validate** — script gate: `python .claude/scripts/hms.py validate patients`
   - FAIL → delegate once to `backend-developer` (or `test-generator` if the failure is only in `tests/`) with the gate output, then validate again. Still FAIL → stop.
7. **review** — agent `code-reviewer` (add "Scope: files in handoff").
   - `VERDICT: FIX` → delegate once to `backend-developer` with the findings, run **validate** again. Anything still open goes into the final report; do not loop further.
8. **ui** — only if the extra is `ui`: agent `frontend-developer`, then `test-generator` (add "Scope: ui"), then `python .claude/scripts/hms.py validate patients --ui`.
9. **finish** — `python .claude/scripts/hms.py mark patients done`, then print ≤8 lines: created files (from the handoff), test result, review verdict, `proposed` assumptions used (from `specs/DECISIONS.md#patients`), run command `uvicorn app.main:app --reload`.
