"""Shared fixtures. Uses an in-memory SQLite DB; schema is created/dropped per test (isolation)."""

import os
import uuid

os.environ["HMS_ENV"] = "test"
os.environ["HMS_DATABASE_URL"] = "sqlite://"

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.core.db import Base, SessionLocal, engine, import_all_models  # noqa: E402
from app.core.roles import Role  # noqa: E402
from app.core.security import create_access_token  # noqa: E402
from app.main import create_app  # noqa: E402


@pytest.fixture(autouse=True)
def _schema():
    import_all_models()
    Base.metadata.create_all(engine)
    yield
    Base.metadata.drop_all(engine)


@pytest.fixture
def db():
    with SessionLocal() as session:
        yield session


@pytest.fixture
def client():
    with TestClient(create_app()) as c:
        yield c


@pytest.fixture
def auth_header():
    """auth_header(Role.ADMIN, user_id=None) -> {"Authorization": "Bearer ..."} (synthetic user)."""

    def _make(role: Role = Role.ADMIN, user_id: uuid.UUID | None = None) -> dict[str, str]:
        token = create_access_token(user_id or uuid.uuid4(), role)
        return {"Authorization": f"Bearer {token}"}

    return _make
