"""Smoke tests for the scaffolded foundation (security, RBAC, audit, app factory, UI client)."""

import uuid

import httpx
import jwt
import pytest
from fastapi import Depends, FastAPI
from fastapi.testclient import TestClient

from app.core.audit import AuditLog, record
from app.core.deps import Principal, require_roles
from app.core.roles import Role
from app.core.security import (
    create_access_token,
    decode_token,
    hash_password,
    verify_password,
)
from ui.api_client import ApiClient, ApiError


def test_password_hash_roundtrip():
    hashed = hash_password("S3cret-pass")
    assert hashed != "S3cret-pass"
    assert verify_password("S3cret-pass", hashed)
    assert not verify_password("wrong", hashed)


def test_password_too_long_rejected():
    with pytest.raises(ValueError):
        hash_password("x" * 73)
    assert not verify_password("x" * 73, hash_password("ok-password"))


def test_token_roundtrip_and_tamper_and_expiry():
    uid = uuid.uuid4()
    token = create_access_token(uid, Role.DOCTOR)
    claims = decode_token(token)
    assert claims["sub"] == str(uid) and claims["role"] == "doctor"
    with pytest.raises(jwt.PyJWTError):
        decode_token(token[:-2] + "xx")
    with pytest.raises(jwt.PyJWTError):
        decode_token(create_access_token(uid, Role.DOCTOR, minutes=-1))


def _rbac_app() -> TestClient:
    app = FastAPI()

    @app.get("/admin-only")
    def admin_only(p: Principal = Depends(require_roles(Role.ADMIN))):
        return {"role": p.role}

    return TestClient(app)


def test_rbac_401_403_200(auth_header):
    c = _rbac_app()
    assert c.get("/admin-only").status_code == 401
    assert c.get("/admin-only", headers=auth_header(Role.PATIENT)).status_code == 403
    assert c.get("/admin-only", headers=auth_header(Role.ADMIN)).status_code == 200


def test_require_roles_denies_empty():
    with pytest.raises(ValueError):
        require_roles()


def test_audit_record_persists(db):
    actor = uuid.uuid4()
    record(db, actor_id=actor, action="create", resource="patient", resource_id=uuid.uuid4())
    db.commit()
    row = db.query(AuditLog).one()
    assert row.actor_id == actor and row.action == "create"


def test_health(client):
    assert client.get("/health").json() == {"status": "ok"}


def test_api_client_error_mapping():
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/ok":
            return httpx.Response(200, json={"a": 1})
        if request.url.path == "/bad":
            return httpx.Response(422, json={"detail": [{"loc": ["x"]}]})
        if request.url.path == "/nf":
            return httpx.Response(404, json={"detail": "Not found"})
        return httpx.Response(500, text="Traceback ...")

    c = ApiClient(base_url="http://test", token="t", transport=httpx.MockTransport(handler))
    assert c.get("/ok") == {"a": 1}
    with pytest.raises(ApiError) as e1:
        c.get("/nf")
    assert e1.value.detail == "Not found"
    with pytest.raises(ApiError) as e2:
        c.get("/bad")
    assert e2.value.detail == "Invalid input"
    with pytest.raises(ApiError) as e3:
        c.get("/boom")
    assert "Traceback" not in e3.value.detail
