"""Alembic environment: models are auto-discovered; empty migrations are skipped."""

from alembic import context
from sqlalchemy import create_engine

from app.core.config import get_settings
from app.core.db import Base, import_all_models

import_all_models()
config = context.config
target_metadata = Base.metadata
url = get_settings().database_url


def process_revision_directives(context_, revision, directives):
    if getattr(config.cmd_opts, "autogenerate", False) and directives[0].upgrade_ops.is_empty():
        directives[:] = []


def run_migrations_offline() -> None:
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        render_as_batch=url.startswith("sqlite"),
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    engine = create_engine(url)
    with engine.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            render_as_batch=url.startswith("sqlite"),
            process_revision_directives=process_revision_directives,
        )
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
