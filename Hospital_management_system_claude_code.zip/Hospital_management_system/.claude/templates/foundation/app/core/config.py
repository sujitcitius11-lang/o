"""Application settings (environment / .env). Secrets are never hard-coded (R08)."""

import secrets
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict

_EPHEMERAL_SECRET = secrets.token_urlsafe(48)
_PLACEHOLDER = "change-me"  # noqa: S105  (value from .env.example, never accepted)


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="HMS_", env_file=".env", extra="ignore")

    env: str = "dev"
    database_url: str = "sqlite:///./hms.db"
    jwt_secret: str | None = None
    jwt_algorithm: str = "HS256"
    jwt_issuer: str = "hms"
    access_token_minutes: int = 30
    api_base_url: str = "http://localhost:8000"
    timezone: str = "UTC"

    @property
    def secret(self) -> str:
        if self.jwt_secret and self.jwt_secret != _PLACEHOLDER:
            return self.jwt_secret
        if self.env in ("dev", "test"):
            return _EPHEMERAL_SECRET  # per-process; tokens die on restart
        raise RuntimeError("HMS_JWT_SECRET must be set outside dev/test")


@lru_cache
def get_settings() -> Settings:
    return Settings()
