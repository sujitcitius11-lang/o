"""Role vocabulary shared by auth, RBAC dependencies, and tests."""

from enum import StrEnum


class Role(StrEnum):
    ADMIN = "admin"
    DOCTOR = "doctor"
    RECEPTIONIST = "receptionist"
    PATIENT = "patient"
    LAB_TECHNICIAN = "lab_technician"
    PHARMACIST = "pharmacist"
