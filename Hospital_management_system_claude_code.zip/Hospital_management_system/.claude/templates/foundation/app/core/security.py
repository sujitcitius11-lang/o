"""Password hashing (bcrypt) and JWT helpers (R05)."""

import uuid
from datetime import UTC, datetime, timedelta

import bcrypt
import jwt

from app.core.config import get_settings
from app.core.roles import Role

MAX_PASSWORD_BYTES = 72  # bcrypt limit


def hash_password(password: str) -> str:
    raw = password.encode("utf-8")
    if len(raw) > MAX_PASSWORD_BYTES:
        raise ValueError("password too long")
    return bcrypt.hashpw(raw, bcrypt.gensalt()).decode("ascii")


def verify_password(password: str, hashed: str) -> bool:
    raw = password.encode("utf-8")
    if len(raw) > MAX_PASSWORD_BYTES:
        return False
    try:
        return bcrypt.checkpw(raw, hashed.encode("ascii"))
    except ValueError:
        return False


def create_access_token(user_id: uuid.UUID, role: Role, minutes: int | None = None) -> str:
    s = get_settings()
    now = datetime.now(UTC)
    payload = {
        "sub": str(user_id),
        "role": Role(role).value,
        "iat": now,
        "exp": now + timedelta(minutes=minutes if minutes is not None else s.access_token_minutes),
        "iss": s.jwt_issuer,
    }
    return jwt.encode(payload, s.secret, algorithm=s.jwt_algorithm)


def decode_token(token: str) -> dict:
    """Raise jwt.PyJWTError on any problem (signature, expiry, issuer, missing claims)."""
    s = get_settings()
    return jwt.decode(
        token,
        s.secret,
        algorithms=[s.jwt_algorithm],
        issuer=s.jwt_issuer,
        options={"require": ["exp", "iat", "sub", "role", "iss"]},
    )
