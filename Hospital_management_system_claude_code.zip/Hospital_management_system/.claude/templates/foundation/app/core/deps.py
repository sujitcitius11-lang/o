"""Authentication and role-based authorization dependencies (R04). Deny by default."""

import uuid
from dataclasses import dataclass
from typing import Annotated

import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from app.core.roles import Role
from app.core.security import decode_token

_bearer = HTTPBearer(auto_error=False)


@dataclass(frozen=True)
class Principal:
    user_id: uuid.UUID
    role: Role


def _unauthorized() -> HTTPException:
    return HTTPException(
        status.HTTP_401_UNAUTHORIZED,
        "Not authenticated",
        headers={"WWW-Authenticate": "Bearer"},
    )


def get_current_principal(
    creds: Annotated[HTTPAuthorizationCredentials | None, Depends(_bearer)],
) -> Principal:
    if creds is None:
        raise _unauthorized()
    try:
        claims = decode_token(creds.credentials)
        return Principal(user_id=uuid.UUID(claims["sub"]), role=Role(claims["role"]))
    except (jwt.PyJWTError, ValueError, KeyError):
        raise _unauthorized() from None


def require_roles(*roles: Role):
    """Dependency factory: 401 if unauthenticated, 403 if role not allowed."""
    if not roles:
        raise ValueError("require_roles needs at least one role (deny by default)")
    allowed = frozenset(roles)

    def _checker(principal: Annotated[Principal, Depends(get_current_principal)]) -> Principal:
        if principal.role not in allowed:
            raise HTTPException(status.HTTP_403_FORBIDDEN, "Forbidden")
        return principal

    return _checker
