"""Audit trail (R07). Never pass PHI, request bodies, tokens, or secrets."""

import uuid
from datetime import UTC, datetime

from sqlalchemy import DateTime, String, Uuid
from sqlalchemy.orm import Mapped, Session, mapped_column

from app.core.db import Base, UUIDPkMixin


class AuditLog(UUIDPkMixin, Base):
    __tablename__ = "audit_log"

    actor_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, nullable=True, index=True)
    action: Mapped[str] = mapped_column(String(64))
    resource: Mapped[str] = mapped_column(String(64))
    resource_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC))


def record(
    db: Session,
    *,
    actor_id: uuid.UUID | None,
    action: str,
    resource: str,
    resource_id: uuid.UUID | None = None,
) -> None:
    """Add an audit row to the caller's session; the caller commits it with the business change."""
    db.add(AuditLog(actor_id=actor_id, action=action, resource=resource, resource_id=resource_id))
