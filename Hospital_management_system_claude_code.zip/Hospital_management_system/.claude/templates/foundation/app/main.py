"""FastAPI app factory. Routers are auto-included from app/modules/<m>/router.py."""

import importlib
import pkgutil

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse


def create_app() -> FastAPI:
    import app.modules as modules

    api = FastAPI(title="HMS API")

    for info in pkgutil.iter_modules(modules.__path__):
        name = f"app.modules.{info.name}.router"
        try:
            mod = importlib.import_module(name)
        except ModuleNotFoundError as exc:
            if exc.name == name:
                continue
            raise
        api.include_router(mod.router)

    @api.get("/health", tags=["meta"])
    def health() -> dict[str, str]:
        return {"status": "ok"}

    @api.exception_handler(Exception)
    async def _unhandled(_: Request, __: Exception) -> JSONResponse:  # R14: no internals leaked
        return JSONResponse({"detail": "Internal server error"}, status_code=500)

    return api


app = create_app()
