"""The only way Streamlit pages talk to the backend (R15). Holds just the bearer token (R16)."""

from typing import Any

import httpx

from app.core.config import get_settings


class ApiError(Exception):
    """Safe, user-displayable API failure (never carries server internals)."""

    def __init__(self, status_code: int, detail: str):
        super().__init__(detail)
        self.status_code = status_code
        self.detail = detail


class ApiClient:
    def __init__(
        self,
        base_url: str | None = None,
        token: str | None = None,
        transport: httpx.BaseTransport | None = None,
    ):
        self.base_url = (base_url or get_settings().api_base_url).rstrip("/")
        self.token = token
        self._transport = transport

    def request(self, method: str, path: str, **kwargs: Any) -> Any:
        headers = dict(kwargs.pop("headers", {}) or {})
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        try:
            with httpx.Client(
                base_url=self.base_url, timeout=10.0, transport=self._transport
            ) as client:
                resp = client.request(method, path, headers=headers, **kwargs)
        except httpx.HTTPError:
            raise ApiError(0, "Cannot reach the server") from None
        if resp.status_code >= 500:
            raise ApiError(resp.status_code, "Server error, please try again")
        if resp.status_code >= 400:
            try:
                detail = resp.json().get("detail", "Request failed")
            except ValueError:
                detail = "Request failed"
            if not isinstance(detail, str):
                detail = "Invalid input"
            raise ApiError(resp.status_code, detail)
        return None if resp.status_code == 204 or not resp.content else resp.json()

    def get(self, path: str, **kw: Any) -> Any:
        return self.request("GET", path, **kw)

    def post(self, path: str, **kw: Any) -> Any:
        return self.request("POST", path, **kw)

    def patch(self, path: str, **kw: Any) -> Any:
        return self.request("PATCH", path, **kw)

    def delete(self, path: str, **kw: Any) -> Any:
        return self.request("DELETE", path, **kw)

    def login(self, email: str, password: str) -> dict:
        data = self.post("/auth/login", json={"email": email, "password": password})
        self.token = data["access_token"]
        return data


def get_client() -> ApiClient:
    """Client bound to the Streamlit session token."""
    import streamlit as st

    client = ApiClient(token=st.session_state.get("token"))
    return client
