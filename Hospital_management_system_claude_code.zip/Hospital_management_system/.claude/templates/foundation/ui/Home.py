"""Streamlit entry point: `streamlit run ui/Home.py`. Pages live in ui/pages/."""

import streamlit as st

from ui.api_client import ApiError, get_client

st.set_page_config(page_title="HMS", page_icon="🏥")
st.title("Hospital Management System")

if st.session_state.get("token"):
    st.success("Signed in. Use the sidebar to open a module.")
    if st.button("Sign out"):
        st.session_state.pop("token", None)
        st.rerun()
else:
    with st.form("login"):
        email = st.text_input("Email")
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("Sign in")
    if submitted:
        try:
            client = get_client()
            client.login(email, password)
            st.session_state["token"] = client.token  # token only (R16)
            st.rerun()
        except ApiError as err:
            st.error(err.detail)
