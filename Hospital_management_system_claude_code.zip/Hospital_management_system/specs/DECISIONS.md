# Decisions — authority for spec open questions

Pipelines read the `## <module>` section for the module being built (R02).
Status: `approved` = human-signed-off · `proposed` = pipeline builds with these defaults and lists them in its final report · `blocked` = pipeline skips the module.
Edit a bullet to change behavior, then rerun that module's pipeline. Section header must equal the spec file name (without `.md`).

## global
Status: proposed
- Stack is FastAPI + Streamlit (supersedes the BRD's Java/Angular statements). Super Admin role is out of scope: the `Role` enum has no such value.
- Timestamps stored in UTC. Hospital timezone for day boundaries and slots: env `HMS_TIMEZONE`, default `UTC`. Money: `Decimal(12,2)`, single currency, not modeled.
- Every list endpoint takes `limit` (default 50, max 200) and `offset`, ordered by `created_at, id`.
- Access token: HS256, 30 min, claims `sub`, `role`, `iat`, `exp`, `iss=hms`. No refresh, no revocation list; logout is client-side token discard; a deactivated user keeps access until token expiry (accepted limitation).
- No hard deletes of clinical, financial, or identity records; use status flags.

## auth
Status: proposed
- Roles (lowercase values): admin, doctor, receptionist, patient, lab_technician, pharmacist.
- `POST /auth/register` creates role `patient` only; a `role` field in the body is rejected (422).
- Staff accounts: Admin-only `POST /users`. `PATCH /users/{id}`: Admin changes role, status, name, contact; Admin cannot deactivate or demote self.
- First admin: `python -m app.modules.auth.cli create-admin --email <e>` (password via prompt, never argv).
- Password: min 8, max 72 bytes (bcrypt limit); no reset flow, no lockout (out of scope). Email: strip + lowercase, unique.
- Login failures (unknown, wrong password, inactive) return the same generic 401.
- `POST /auth/logout` returns 204 and writes an audit event. Audit: register, login success/failure, logout, role/status change.

## patients
Status: proposed
- `medical_history`: one free-text field (≤5000 chars). `allergies`: list of strings in the API, stored comma-joined. No MRN; UUID is the identifier.
- Duplicate rule: same normalized name + dob + contact number → 409.
- `POST /patients`: a patient-role caller creates their own profile (linked to their user); a Receptionist creates user + profile atomically with an initial password.
- Patient self-edit: contact number, address, emergency contact, allergies. Receptionist/Admin edit all demographic fields. Only Admin sets `is_active=false`.
- Doctor: read by id only (any patient); no list/search for doctors. Assignment-based restriction is deferred until appointments exist (listed as an assumption).
- `GET /patients`: Receptionist, Admin. No delete endpoint.

## doctors-departments
Status: proposed
- Services CRUD is **blocked** (schema undefined): implement doctors and departments only.
- Availability: weekly rows (weekday 0-6, start, end) plus `slot_minutes` per doctor (default 15); no exceptions or holidays.
- Readable by any authenticated role: name, department, qualification, availability. Contact number visible to Admin only.
- Doctor profile: Admin links an existing user with role `doctor` (1:1 unique); `is_active` flag, no delete.
- Departments: unique name; any authenticated role reads; Admin writes; delete allowed only when no doctors (else 409).

## appointments
Status: proposed
- Start time must be on the doctor's slot grid, inside availability, in the future; no overlap with another `scheduled` appointment of that doctor; no buffer.
- States: `scheduled` → `completed` | `cancelled` | `no_show` (terminal). Reschedule = change start time while `scheduled`, same validations.
- Patient: book/cancel/reschedule own. Receptionist: book/cancel/reschedule any. Doctor: only own assigned; may set `completed`/`no_show` and edit `visit_notes`.
- Notifications are **out of initial scope**.

## prescriptions
Status: proposed
- `diagnosis`: free text (≤2000). Medicines: child rows (name, strength, route, frequency, duration_days, quantity, instructions); no coding system.
- One prescription per appointment, by the assigned Doctor, appointment `scheduled` or `completed`; does not auto-complete the appointment.
- Immutable after creation (no PATCH). Amendments, refills, signing: **out of scope**.
- Patient sees own immediately; Pharmacist may read any prescription for dispensing; Doctor reads own.

## lab
Status: proposed
- File upload **out of initial scope**: store metadata plus an opaque `file_reference` string only (validated charset, never a path).
- No lab-order workflow: any Lab Technician creates a report for any patient. Single status `final`; corrections out of scope.
- Read: Patient own; Doctor any patient; Lab Technician reports they created; Admin none.

## pharmacy
Status: proposed
- Medicine: name, strength, form, unit price, stock (int ≥ 0), expiry date. No SKU, batch, or supplier.
- Stock changes only through `stock_movements` (receive | adjust | dispense) with a reason; `PATCH /medicines` cannot set stock. Pharmacist and Admin manage; Doctors have no access.
- Dispense: full fill only, against prescription items; quantity ≤ remaining prescribed; expired stock always refused; atomic conditional decrement. No substitutions or returns.

## billing
Status: proposed
- Bill items: description, quantity, unit price; total computed server-side from an immutable item snapshot; no tax or discounts. Identifier is UUID (no sequential bill number). Optional `appointment_id` reference only.
- Payments: Receptionist/Admin record amount, mode (cash | card | upi | other), optional reference. Bill status derived: `unpaid`, `partially_paid`, `paid`. Overpayment → 422. Multiple payments allowed.
- Gateway/callbacks, refunds, and voids are **blocked** (not implemented).

## reports
Status: proposed
- Admin only. Date range required (`from`, `to` inclusive, ≤366 days) in hospital timezone.
- Revenue = sum of payments received in range. Patients seen = distinct patients with `completed` appointments. Top departments = completed appointments per doctor department, ties by name, top 10.
- Aggregates only (no patient identifiers). Export: CSV only; PDF **blocked**.
