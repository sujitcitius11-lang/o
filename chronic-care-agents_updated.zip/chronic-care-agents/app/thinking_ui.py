"""Animated "thinking" bubble shown while the agents work (pure HTML/CSS/SVG, rendered once - no polling).

    heartbeat  an ECG line sweeping across with a glowing dot riding the pulse
    status     one step at a time, cross-fading, with a soft shimmer (steps match the member's question)
    progress   small dots that fill in as the steps advance
"""

from __future__ import annotations

import html


STEP_SECONDS = 1.8

_KEYS = [
    (("reading", "glucose", "blood pressure", "sugar", "summar"), ["Reading the self-reported log", "Looking for missed days"]),
    (("task", "reminder", "due", "plan"), ["Opening the care plan", "Preparing a reminder"]),
    (("dose", "insulin", "medicine", "tablet", "stop taking"), ["Noting the medicine question"]),
    (("dangerous", "serious", "worried", "doctor"), ["Looping in the care team"]),
]


# One heartbeat: flat, small P wave, sharp QRS spike, T wave, flat (viewBox 0 0 120 40).
_ECG = "M0 24 H30 Q34 19 38 24 H44 L48 30 L54 6 L60 34 L64 24 H72 Q78 16 84 24 H120"


def thinking_steps(message: str) -> list[str]:
    """Status lines that roughly match what the agents will do for this message (display only)."""
    low = (message or "").lower()
    steps = ["Checking consent and safety rules", "Routing your question"]
    matched = False
    for keys, lines in _KEYS:
        if any(w in low for w in keys):
            steps += lines
            matched = True
    if not matched:
        steps += ["Searching approved articles", "Checking every source"]
    return steps + ["Running output safety checks", "Putting it together"]


def thinking_html(message: str) -> str:
    steps = thinking_steps(message)
    n, t = len(steps), STEP_SECONDS
    lines = "".join(
        f'<div class="cc-step{" cc-last" if i == n - 1 else ""}" style="animation-delay:{i * t:.2f}s">'
        f"{html.escape(text)}</div>"
        for i, text in enumerate(steps)
    )
    dots = "".join(f'<i style="animation-delay:{i * t:.2f}s"></i>' for i in range(n))
    markup = f"""
<div class="cc-think" style="--cc-step:{t}s">
  <svg class="cc-ecg" viewBox="0 0 120 40" aria-hidden="true">
    <path class="cc-ecg-base" d="{_ECG}"/>
    <path class="cc-ecg-trace" d="{_ECG}" pathLength="100"/>
    <circle class="cc-ecg-dot" r="2.6"><animateMotion dur="1.6s" repeatCount="indefinite" path="{_ECG}"/></circle>
  </svg>
  <div class="cc-text">
    <div class="cc-steps">{lines}</div>
    <div class="cc-dots">{dots}</div>
  </div>
</div>"""
    # Flatten: Streamlit's markdown would turn 4-space-indented lines into code blocks.
    return "".join(line.strip() for line in markup.splitlines())


THINKING_CSS = """
.cc-think {display:inline-flex; align-items:center; gap:.9rem; padding:.7rem 1.1rem .7rem .8rem; max-width:100%;
           background:#fff; border:1px solid #e3ece9; border-radius:16px; box-shadow:0 4px 18px rgba(15,118,110,.08);
           animation:cc-in .35s ease both;}
.cc-ecg {width:96px; height:34px; flex:none; overflow:visible;}
.cc-ecg path {fill:none; stroke-linecap:round; stroke-linejoin:round;}
.cc-ecg-base {stroke:#d7ebe6; stroke-width:2;}
.cc-ecg-trace {stroke:#0f766e; stroke-width:2.4; stroke-dasharray:28 72; animation:cc-sweep 1.6s linear infinite;
               filter:drop-shadow(0 0 3px rgba(20,184,166,.55));}
.cc-ecg-dot {fill:#14b8a6; filter:drop-shadow(0 0 4px rgba(20,184,166,.9));}
.cc-text {min-width:13.5rem;}
.cc-steps {position:relative; height:1.45em; font-size:.95rem; font-weight:500;}
.cc-step {position:absolute; inset:0; white-space:nowrap; opacity:0;
          background:linear-gradient(90deg,#4b5b56 0%,#4b5b56 40%,#14b8a6 50%,#4b5b56 60%,#4b5b56 100%);
          background-size:300% 100%; -webkit-background-clip:text; background-clip:text; color:transparent;
          animation:cc-step var(--cc-step) ease both, cc-shine 2.2s linear infinite;}
.cc-step.cc-last {animation:cc-step-stay .5s ease both, cc-shine 2.2s linear infinite;}
.cc-step::after {content:"…";}
.cc-dots {display:flex; gap:5px; margin-top:.4rem;}
.cc-dots i {width:6px; height:6px; border-radius:50%; background:#dfe9e6; animation:cc-dot .4s ease forwards;}
.cc-thought {font-size:.74rem; color:#8a9a95; margin-top:.35rem;}
[data-testid="stChatMessage"] .card, [data-testid="stChatMessage"] .chips, [data-testid="stChatMessage"] .task,
[data-testid="stChatMessage"] .label, [data-testid="stChatMessage"] .answer {animation:cc-in .45s ease both;}
@keyframes cc-sweep {from {stroke-dashoffset:100;} to {stroke-dashoffset:0;}}
@keyframes cc-shine {from {background-position:100% 0;} to {background-position:-200% 0;}}
@keyframes cc-step {0% {opacity:0; transform:translateY(5px);} 14% {opacity:1; transform:none;}
                    84% {opacity:1; transform:none;} 100% {opacity:0; transform:translateY(-5px);}}
@keyframes cc-step-stay {from {opacity:0; transform:translateY(5px);} to {opacity:1; transform:none;}}
@keyframes cc-dot {to {background:#14b8a6; transform:scale(1.15);}}
@keyframes cc-in {from {opacity:0; transform:translateY(6px);} to {opacity:1; transform:none;}}
@media (prefers-reduced-motion: reduce) {
  .cc-ecg-trace, .cc-step, .cc-dots i {animation-duration:.01s !important;}
}
"""
